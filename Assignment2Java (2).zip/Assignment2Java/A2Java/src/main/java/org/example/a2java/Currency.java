package org.example.a2java; // Defines the package in which the class resides.

public class Currency { // Defines the Currency class.
    public String code; // Public field to store the currency code.
    public double rate; // Public field to store the exchange rate.

    // Constructor
    public Currency(String code, double rate) { // Constructor that initializes the Currency object with a code and rate.
        this.code = code; // Sets the currency code.
        this.rate = rate; // Sets the exchange rate.
    }

    // Getter for code
    public String getCode() { // Method to get the currency code.
        return code; // Returns the currency code.
    }

    // Setter for code
    public void setCode(String code) { // Method to set the currency code.
        if (code != null && !code.isEmpty()) { // Checks if the provided code is not null and not empty.
            this.code = code; // Sets the currency code.
        } else {
            throw new IllegalArgumentException("Code cannot be null or empty"); // Throws an exception if the code is null or empty.
        }
    }

    // Getter for rate
    public double getRate() { // Method to get the exchange rate.
        return rate; // Returns the exchange rate.
    }

    // Setter for rate
    public void setRate(double rate) { // Method to set the exchange rate.
        if (rate >= 0) { // Checks if the provided rate is not negative.
            this.rate = rate; // Sets the exchange rate.
        } else {
            throw new IllegalArgumentException("Rate cannot be negative"); // Throws an exception if the rate is negative.
        }
    }

    // Override toString method
    @Override
    public String toString() { // Overrides the toString method to provide a custom string representation of the Currency object.
        return "Currency code: " + code + ", Exchange rate: " + rate; // Returns a string representing the currency code and exchange rate.
    }

    // Method to check if two Currency objects are equal
    @Override
    public boolean equals(Object obj) { // Overrides the equals method to compare Currency objects for equality.
        if (this == obj) return true; // Checks if the objects are the same instance.
        if (obj == null || getClass() != obj.getClass()) return false; // Checks if the object is null or not of the same class.

        Currency currency = (Currency) obj; // Casts the object to a Currency instance.

        return Double.compare(currency.rate, rate) == 0 && code.equals(currency.code); // Compares the currency codes and rates for equality.
    }

    // Method to generate hashCode for Currency object
    @Override
    public int hashCode() { // Overrides the hashCode method to generate a hash code for the Currency object.
        int result; // Variable to store the result of hash code computation.
        long temp; // Variable to store the double rate as a long value.
        result = code.hashCode(); // Computes the hash code based on the currency code.
        temp = Double.doubleToLongBits(rate); // Converts the double rate to its long bits representation.
        result = 31 * result + (int) (temp ^ (temp >>> 32)); // Computes the final hash code using the currency rate.
        return result; // Returns the computed hash code.
    }
}
