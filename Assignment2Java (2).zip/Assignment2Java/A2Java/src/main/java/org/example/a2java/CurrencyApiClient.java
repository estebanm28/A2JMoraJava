package org.example.a2java; // Defines the package in which the class resides.

import java.net.URI; // Imports URI class for handling URIs.
import java.net.http.HttpClient; // Imports HttpClient for sending HTTP requests.
import java.net.http.HttpRequest; // Imports HttpRequest for creating HTTP requests.
import java.net.http.HttpResponse; // Imports HttpResponse for handling HTTP responses.
import java.util.Map; // Imports Map interface for storing key-value pairs.
import com.google.gson.Gson; // Imports Gson for JSON parsing.
import com.google.gson.JsonObject; // Imports JsonObject for handling JSON objects.
import com.google.gson.JsonParser; // Imports JsonParser for parsing JSON strings.

public class CurrencyApiClient { // Defines the CurrencyApiClient class.

    private static final String API_URL = "https://v6.exchangerate-api.com/v6/ab7879778a62bc04f222385b/latest/"; // Base URL for the currency exchange rate API.

    public static Map<String, Double> fetchExchangeRates(String baseCurrencyCode) { // Method to fetch exchange rates for a given base currency.
        String url = API_URL + baseCurrencyCode; // Constructs the full API URL using the base currency code.
        try {
            HttpClient client = HttpClient.newHttpClient(); // Creates a new HttpClient instance.
            HttpRequest request = HttpRequest.newBuilder() // Builds an HTTP request.
                    .uri(URI.create(url)) // Sets the request URI to the constructed URL.
                    .build(); // Builds the request.
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString()); // Sends the request and retrieves the response as a string.

            if (response.statusCode() == 200) { // Checks if the response status code is 200 (OK).
                String jsonResponse = response.body(); // Gets the response body as a string.
                return parseJsonResponse(jsonResponse); // Parses the JSON response and returns the exchange rates.
            } else {
                System.out.println("Error: " + response.statusCode()); // Prints an error message if the status code is not 200.
                return null; // Returns null if there was an error.
            }
        } catch (Exception e) {
            e.printStackTrace(); // Prints the stack trace if an exception occurs.
            return null; // Returns null in case of an exception.
        }
    }

    private static Map<String, Double> parseJsonResponse(String jsonResponse) { // Method to parse the JSON response.
        Gson gson = new Gson(); // Creates a new Gson instance for JSON parsing.
        JsonObject jsonObject = JsonParser.parseString(jsonResponse).getAsJsonObject(); // Parses the JSON string into a JsonObject.
        JsonObject conversionRates = jsonObject.getAsJsonObject("conversion_rates"); // Extracts the conversion_rates object from the JsonObject.
        return gson.fromJson(conversionRates, Map.class); // Converts the conversion_rates object into a Map and returns it.
    }

    public static void main(String[] args) { // Main method, the entry point of the application.
        String baseCurrencyCode = "USD"; // Sets the base currency code for fetching exchange rates.
        Map<String, Double> exchangeRates = fetchExchangeRates(baseCurrencyCode); // Fetches exchange rates for the specified base currency.
        if (exchangeRates != null) { // Checks if the exchange rates map is not null.
            exchangeRates.forEach((currency, rate) -> System.out.println(currency + ": " + rate)); // Prints each currency code and its exchange rate.
        }
    }
}
