package org.example.a2java; // Defines the package in which the class resides.

import javafx.application.Application; // Imports the Application class from the JavaFX library.
import javafx.fxml.FXMLLoader; // Imports the FXMLLoader class for loading FXML files.
import javafx.scene.Scene; // Imports the Scene class for creating scenes in JavaFX.
import javafx.stage.Stage; // Imports the Stage class for creating application windows.

import java.io.IOException; // Imports the IOException class for handling IO exceptions.

public class CurrencyApplication extends Application { // Defines the CurrencyApplication class extending the Application class.
    @Override
    public void start(Stage stage) throws IOException { // Overrides the start method to set up the main stage (window) of the application.
        FXMLLoader mainLoader = new FXMLLoader(CurrencyApplication.class.getResource("main-screen.fxml")); // Creates an FXMLLoader instance for the main screen FXML file.
        Scene mainScene = new Scene(mainLoader.load(), 400, 300); // Loads the main screen FXML and creates a Scene with dimensions 400x300.

        // Set up the initial main screen
        stage.setTitle("Currency Converter"); // Sets the title of the application window.
        stage.setScene(mainScene); // Sets the scene of the stage to the main screen scene.
        stage.show(); // Displays the stage (window) with the main screen.

        // Switch to the currency converter screen after a few seconds
        new Thread(() -> { // Creates a new thread to handle the screen transition.
            try {
                Thread.sleep(3000); // Pauses the thread for 3 seconds to display the main screen.
                FXMLLoader converterLoader = new FXMLLoader(CurrencyApplication.class.getResource("currency-view.fxml")); // Creates an FXMLLoader instance for the currency converter FXML file.
                Scene converterScene = new Scene(converterLoader.load(), 400, 300); // Loads the currency converter FXML and creates a Scene with dimensions 400x300.

                // Switch to the currency converter screen
                javafx.application.Platform.runLater(() -> stage.setScene(converterScene)); // Switches to the currency converter scene on the JavaFX application thread.
            } catch (IOException | InterruptedException e) { // Catches IOException and InterruptedException.
                e.printStackTrace(); // Prints the stack trace for any caught exceptions.
            }
        }).start(); // Starts the new thread to handle the screen transition.
    }

    public static void main(String[] args) { // Defines the main method, which is the entry point of the Java application.
        launch(); // Launches the JavaFX application.
    }
}
