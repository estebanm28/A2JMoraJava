package org.example.a2java; // Defines the package in which the class resides.

import javafx.fxml.FXML; // Imports the FXML annotation from the JavaFX library.
import javafx.scene.control.ComboBox; // Imports the ComboBox class for dropdown menus in JavaFX.
import javafx.scene.control.Label; // Imports the Label class for displaying text in JavaFX.
import javafx.scene.control.TextField; // Imports the TextField class for user input in JavaFX.

import java.util.Map; // Imports the Map interface for handling key-value pairs.

public class CurrencyController { // Defines the CurrencyController class.

    @FXML
    private ComboBox<String> baseCurrencyComboBox; // Declares a ComboBox for selecting the base currency.
    @FXML
    private ComboBox<String> targetCurrencyComboBox; // Declares a ComboBox for selecting the target currency.
    @FXML
    private TextField amountTextField; // Declares a TextField for inputting the amount to convert.
    @FXML
    private Label resultLabel; // Declares a Label for displaying the conversion result.

    @FXML
    public void initialize() { // Initializes the controller after the FXML components are loaded.
        // Initialize combo boxes with some common currencies
        String[] currencies = {"USD", "EUR", "GBP", "JPY", "AUD"}; // Defines a list of common currencies.
        baseCurrencyComboBox.getItems().addAll(currencies); // Adds the list of currencies to the base currency ComboBox.
        targetCurrencyComboBox.getItems().addAll(currencies); // Adds the list of currencies to the target currency ComboBox.

        // Set default values
        baseCurrencyComboBox.setValue("USD"); // Sets the default value of the base currency ComboBox to USD.
        targetCurrencyComboBox.setValue("EUR"); // Sets the default value of the target currency ComboBox to EUR.
    }

    @FXML
    public void handleConvertButtonAction() { // Handles the action when the convert button is clicked.
        String baseCurrency = baseCurrencyComboBox.getValue(); // Retrieves the selected base currency.
        String targetCurrency = targetCurrencyComboBox.getValue(); // Retrieves the selected target currency.
        double amount;

        try {
            amount = Double.parseDouble(amountTextField.getText()); // Parses the amount entered by the user.
        } catch (NumberFormatException e) { // Catches any NumberFormatException if the input is not a valid number.
            resultLabel.setText("Invalid amount"); // Sets the result label to show an error message.
            return; // Exits the method if the amount is invalid.
        }

        Map<String, Double> exchangeRates = CurrencyApiClient.fetchExchangeRates(baseCurrency); // Fetches the exchange rates for the base currency.
        if (exchangeRates != null) { // Checks if exchange rates were successfully retrieved.
            if (exchangeRates.containsKey(targetCurrency)) { // Checks if the target currency rate is available.
                double rate = exchangeRates.get(targetCurrency); // Retrieves the conversion rate for the target currency.
                double convertedAmount = amount * rate; // Calculates the converted amount.
                resultLabel.setText(String.format("%.2f %s = %.2f %s", amount, baseCurrency, convertedAmount, targetCurrency)); // Displays the conversion result.
            } else {
                resultLabel.setText("Conversion rate not available for " + targetCurrency); // Displays an error message if the target currency rate is not available.
            }
        } else {
            resultLabel.setText("Failed to retrieve exchange rates"); // Displays an error message if exchange rates could not be retrieved.
        }
    }
}

